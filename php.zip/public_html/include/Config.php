<?php

/**
 * Database config variables
 */
define("DB_HOST", "mysql5.000webhost.com");
define("DB_USER", "a1050813_its");
define("DB_PASSWORD", "agea85203");
define("DB_DATABASE", "a1050813_ageaits");
?>

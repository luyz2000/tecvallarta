<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form name="frmAlumno" action="Ejemplo.php" method="POST">
            
            Numero de control:<input type="text" name="txtNControl" /><br>
            Nombre: <input type="text" name="txtNombre" /><br>
            Telefono: <input type="text" name="txtTelefono" /><br>
            
            
            <input type="submit" value="Guardar" />
       </form>
        
        <?php
       echo "hola";
        ?>
    </body>
</html>
